DELIMITER //
CREATE TRIGGER stimmenTrigger
AFTER UPDATE ON sprengelstimmen
FOR EACH ROW
BEGIN
  INSERT INTO wahlstimmen VALUES ((select count(gueltige_Stimmen) from sprengelstimmen));
END; //
DELIMITER ;
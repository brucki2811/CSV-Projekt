author__ = 'Bruckner Michael'
__version__ = 1.0
__date__ = 20160321

from PySide.QtCore import QAbstractTableModel, Qt

class Table(QAbstractTableModel):
    def __init__(self, daten, header):
        super().__init__()
        self.daten = daten
        self.header = header

    def data(self, index, role):
        if not index.isValid():
            return None
        elif role != Qt.DisplayRole:
            return None
        return self.daten[index.row()][index.column()]

    def rowCount(self, parent):
        return len(self.daten)

    def columnCount(self, parent):
        return len(self.daten[0])

    def headerData(self, col, orientation, role):
        if orientation == Qt.Horizontal and role == Qt.DisplayRole:
            return self.header[col]
        return None

    def flags(self, *args, **kwargs):
        return Qt.ItemIsEditable | Qt.ItemIsSelectable | Qt.ItemIsEnabled

    def setData(self, index, value, role):
        self.daten[index.row()][index.column()] = value
        return True

    def insertRow(self, row, rows=1, insert_data=""):
        self.layoutAboutToBeChanged.emit()
        for tmp in range(rows):
            self.daten.insert(row, [insert_data for x in range(0, len(self.daten[0]))])
        self.layoutChanged.emit()

    def duplizieren(self, row, rows=1, insert_data=""):
        self.layoutAboutToBeChanged.emit()
        for tmp in range(rows):
            self.daten.insert(row, [insert_data for x in range(0, len(self.daten[0]))])
        self.layoutChanged.emit()

    def zweidimensionalesarray(self):
        table_data = self.daten
        table_header = self.header
        arr = [table_header]
        [arr.append(table_data[x]) for x in range(0, len(table_data))]
        return arr
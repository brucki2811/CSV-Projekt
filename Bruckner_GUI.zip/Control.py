__author__ = 'Bruckner Michael'
__version__ = 2.1
__date__ = 20160321

from GUI import GUI
from sql import SQL
import os
import sys
from PySide.QtGui import *
from PySide import *
from TableModel import Table
from Model import Model
from PySide.QtCore import Qt

class Controller(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.filename = ""
        self.sql = SQL
        self.mwindow = QtGui.QMainWindow()
        self.model = Model(self.mwindow)
        self.gui = GUI.Ui_MainWindow()
        self.gui.setupUi(self)
        self.tableView = self.gui.tableView
        self.role = Qt.DisplayRole
        self.signals()

        self.clipboard_list = []
        self.indexlist = []
        self.history = []
        self.deletelist = []

    def signals(self):
        self.gui.actionOpen.triggered.connect(self.csvfile)
        self.gui.actionExit.triggered.connect(self.closegui)
        self.gui.actionInsert.triggered.connect(self.insertintable)
        self.gui.actionDuplicate.triggered.connect(self.duplicatecell)
        self.gui.actionDelete.triggered.connect(self.deletecell)
        self.gui.actionCopy.triggered.connect(self.copycell)
        #self.gui.actionCut.triggered.connect(self.cutcell)
        self.gui.actionPaste.triggered.connect(self.pastecell)
        #self.gui.actionNew.triggered.connect(self.newfile)
        #self.gui.actionSave.triggered.connect(self.savefile)
        #self.gui.actionSave_As.triggered.connect(self.saveas)

    def closegui(self):
        result = QtGui.QMessageBox.question(QtGui.QWidget(), 'Exit',"Moechten Sie das Programm wirklich beenden?\n Alle ungespeicherten Daten gehen verloren!",
                                            QtGui.QMessageBox.Yes | QtGui.QMessageBox.No, QtGui.QMessageBox.No)
        if result == QtGui.QMessageBox.Yes:
            self.close()
        else:
            pass
        print(Table.data(self, self.index, self.role))

    def csvfile(self):
        """
        Mit dieser Methode wird das ausgewaehlte CSV-File in die Tabelle importiert
        :return:
        """
        fname = QtGui.QFileDialog.getOpenFileName(self.mwindow, 'Open file...', os.getcwd(), "CSV (*.csv)")
        if not fname[0] == '':
            self.model.currentfile = fname[0]
            arr = self.model.read_csv_array(fname[0], delimiter=';')
            tablemodel = Table(arr[1:len(arr)], arr[0])
            self.tableView.setModel(tablemodel)

    def insertintable(self):
        """
        Erzeugt eine neuen Zeile (unterhalb der aktuellen Zeile)
        :return:
        """
        if self.tableView.model() is not None:
            if self.model.currentfile is not None:
                self.tableView.model().insertRow(self.tableView.currentIndex().row() + 1)
        else:
            self.gui.statusbar.showMessage("Es ist kein File geoeffnet !")

    def copycell(self):
        """
        Kopiert einzelne Zellen
        :return:
        """
        name = "copy"
        index = self.tableView.selectionModel().currentIndex()
        self.clipboard_list.append(self.tableView.model().data(index,self.role))
        print("copied to clipboard: ", self.clipboard_list[-1])
        self.history.append(name)

    def pastecell(self):
        """
        Fügt Zelle ein
        :return:
        """
        name = "paste"
        index = self.tableView.selectionModel().currentIndex()
        self.indexlist.append(index)
        self.deletelist.append(self.tableView.model().data(index, self.role))
        self.tableView.model().setData(index, self.clipboard_list[-1], self.role)
        self.hist_list.append(name)


    def duplicatecell(self):
        """
        Duplizieren der aktuellen Zeile (inklusive einfuegen unterhalb der aktuellen Zeile)
        """
        if self.tableView.model() is not None:
            if self.model.currentfile is not None:
                self.tableView.model().duplizieren(self.tableView.currentIndex().row() + 1)
        else:
            self.gui.statusbar.showMessage("Es ist kein File geoeffnet !")

    def selectedcell(self, selected, deselected):
        index = self.tableView.selectionModel().currentIndex()
        print(index.row(), ":", index.column())
        self.tableView.model().submit()

    def deletecell(self):
        """
        Sollte eine Zeile loeschen
        Beisatz nicht so richtig durchdacht muss noch überarbeitet werden!
        :return:
        """
        name = "delete row"
        print(name)
        index = self.tableView.selectionModel().currentIndex()
        old_row_data = []
        for i in range(self.tableView.model().columnCount(), None):
            source_index = self.tableView.model().index(index.row(), i)
            old_row_data.append(self.gui.tableView.model().data(source_index) )
        success = self.gui.tableView.model().removeRows( index.row(), 1 )
        if (success):
            self.indexlist.append(index)
            self.deletelist.append(old_row_data)
            self.history.append(name)
        else:
            print( "Hat nicht funktioniert ups ! :/" )

if __name__ == "__main__":
    app = QtGui.QApplication(sys.argv)
    MainWindow = QtGui.QMainWindow()
    controller = Controller()
    controller.show()
    sys.exit(app.exec_())

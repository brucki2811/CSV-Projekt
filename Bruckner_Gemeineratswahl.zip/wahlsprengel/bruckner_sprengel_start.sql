USE wahlen;
source bruckner_sprengel_drop.sql;
source bruckner_sprengel_create.sql;
source bruckner_sprengel_stimmentrigger.sql;
source bruckner_sprengel_hochrechnung.sql;
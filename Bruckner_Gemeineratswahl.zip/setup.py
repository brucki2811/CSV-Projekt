from distutils.core import setup

setup(
        name='CSV-Projekt',
        version='3.5',
        packages=[''],
        url='https://github.com/brucki2811/CSV-Projekt',
        license='GPL',
        author='michaelbruckner',
        author_email='mbruckner@student.tgm.ac.at',
        description=''
)
